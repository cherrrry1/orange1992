package router

import (
	"github.com/cherrrry1/orange1992/common/dice"
)

// RandomStrategy represents a random balancing strategy
type RandomStrategy struct{}

func (s *RandomStrategy) GetPrincipleTarget(strings []string) []string {
	return strings
}

func (s *RandomStrategy) PickOutbound(candidates []string) string {
	count := len(candidates)
	if count == 0 {
		// goes to fallbackTag
		return ""
	}
	return candidates[dice.Roll(count)]
}
