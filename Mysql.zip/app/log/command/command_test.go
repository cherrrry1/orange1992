package command_test

import (
	"context"
	"testing"

	"github.com/cherrrry1/orange1992/app/dispatcher"
	"github.com/cherrrry1/orange1992/app/log"
	. "github.com/cherrrry1/orange1992/app/log/command"
	"github.com/cherrrry1/orange1992/app/proxyman"
	_ "github.com/cherrrry1/orange1992/app/proxyman/inbound"
	_ "github.com/cherrrry1/orange1992/app/proxyman/outbound"
	"github.com/cherrrry1/orange1992/common"
	"github.com/cherrrry1/orange1992/common/serial"
	"github.com/cherrrry1/orange1992/core"
)

func TestLoggerRestart(t *testing.T) {
	v, err := core.New(&core.Config{
		App: []*serial.TypedMessage{
			serial.ToTypedMessage(&log.Config{}),
			serial.ToTypedMessage(&dispatcher.Config{}),
			serial.ToTypedMessage(&proxyman.InboundConfig{}),
			serial.ToTypedMessage(&proxyman.OutboundConfig{}),
		},
	})
	common.Must(err)
	common.Must(v.Start())

	server := &LoggerServer{
		V: v,
	}
	common.Must2(server.RestartLogger(context.Background(), &RestartLoggerRequest{}))
}
