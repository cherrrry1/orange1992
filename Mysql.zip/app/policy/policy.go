// Package policy is an implementation of policy.Manager feature.
package policy

//go:generate go run github.com/cherrrry1/orange1992/common/errors/errorgen
