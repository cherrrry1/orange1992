// Package net is a drop-in replacement to Golang's net package, with some more functionalities.
package net // import "github.com/cherrrry1/orange1992/common/net"

//go:generate go run github.com/cherrrry1/orange1992/common/errors/errorgen
