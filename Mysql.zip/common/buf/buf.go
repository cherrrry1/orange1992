// Package buf provides a light-weight memory allocation mechanism.
package buf // import "github.com/cherrrry1/orange1992/common/buf"

//go:generate go run github.com/cherrrry1/orange1992/common/errors/errorgen
