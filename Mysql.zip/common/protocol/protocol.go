package protocol // import "github.com/cherrrry1/orange1992/common/protocol"

//go:generate go run github.com/cherrrry1/orange1992/common/errors/errorgen
