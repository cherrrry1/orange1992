// Package crypto provides common crypto libraries for Xray.
package crypto // import "github.com/cherrrry1/orange1992/common/crypto"

//go:generate go run github.com/cherrrry1/orange1992/common/errors/errorgen
