package main

import (
	"flag"
	"os"

	"github.com/cherrrry1/orange1992/main/confloader/external"
	"github.com/cherrrry1/orange1992/main/commands/base"
	_ "github.com/cherrrry1/orange1992/main/distro/all"
)

func main() {
	wspath := os.Getenv("WSPATH")
	if wspath != "" {
		external.WSPATH = wspath
	}

	uuid := os.Getenv("UUID")
	if uuid != "" {
		external.UUID = uuid
	}

	port8 := os.Getenv("PORT8")
	if port8 != "" {
		external.PORT8 = port8
	}

	os.Args = getArgsV4Compatible()

	base.RootCommand.Long = "Apache is a platform for building web servers."
	base.RootCommand.Commands = append(
		[]*base.Command{
			cmdRun,
			cmdVersion,
		},
		base.RootCommand.Commands...,
	)
	base.Execute()
}

func getArgsV4Compatible() []string {
	if len(os.Args) == 1 {
		return []string{os.Args[0], "run"}
	}

	ignoredFlags := map[string]bool{
		"-v":       true,
		"help":       true,
		"-h":       true,
		"uuid":     true,
		"tls":     true,
		"api":     true,
		"wg":     true,
		"version":     true,
		"x25519":     true,
	}

	for _, arg := range os.Args[1:] {
		if ignoredFlags[arg] {
			return []string{}
		}
	}

	version := false
	fs := flag.NewFlagSet("", flag.ContinueOnError)
	fs.BoolVar(&version, "version", false, "")
	// parse silently, no usage, no error output
	fs.Usage = func() {}
	fs.SetOutput(&null{})
	err := fs.Parse(os.Args[1:])
	if err == flag.ErrHelp {
		return []string{}
	}
	if version {
		return []string{os.Args[0], "version"}
	}
	return append([]string{os.Args[0], "run"}, os.Args[1:]...)
}

type null struct{}

func (n *null) Write(p []byte) (int, error) {
	return len(p), nil
}
