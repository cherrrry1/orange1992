package all

import (
	// The following are necessary as they register handlers in their init functions.

	// Mandatory features. Can't remove unless there are replacements.
	_ "github.com/cherrrry1/orange1992/app/dispatcher"
	_ "github.com/cherrrry1/orange1992/app/proxyman/inbound"
	_ "github.com/cherrrry1/orange1992/app/proxyman/outbound"

	// Default commander and all its services. This is an optional feature.
	_ "github.com/cherrrry1/orange1992/app/commander"
	_ "github.com/cherrrry1/orange1992/app/log/command"
	_ "github.com/cherrrry1/orange1992/app/proxyman/command"
	_ "github.com/cherrrry1/orange1992/app/stats/command"

	// Developer preview services
	_ "github.com/cherrrry1/orange1992/app/observatory/command"

	// Other optional features.
	_ "github.com/cherrrry1/orange1992/app/dns"
	_ "github.com/cherrrry1/orange1992/app/dns/fakedns"
	_ "github.com/cherrrry1/orange1992/app/log"
	_ "github.com/cherrrry1/orange1992/app/metrics"
	_ "github.com/cherrrry1/orange1992/app/policy"
	_ "github.com/cherrrry1/orange1992/app/reverse"
	_ "github.com/cherrrry1/orange1992/app/router"
	_ "github.com/cherrrry1/orange1992/app/stats"

	// Fix dependency cycle caused by core import in internet package
	_ "github.com/cherrrry1/orange1992/transport/internet/tagged/taggedimpl"

	// Developer preview features
	_ "github.com/cherrrry1/orange1992/app/observatory"

	// Inbound and outbound proxies.
	_ "github.com/cherrrry1/orange1992/proxy/blackhole"
	_ "github.com/cherrrry1/orange1992/proxy/dns"
	_ "github.com/cherrrry1/orange1992/proxy/dokodemo"
	_ "github.com/cherrrry1/orange1992/proxy/freedom"
	_ "github.com/cherrrry1/orange1992/proxy/http"
	_ "github.com/cherrrry1/orange1992/proxy/loopback"
	_ "github.com/cherrrry1/orange1992/proxy/shadowsocks"
	_ "github.com/cherrrry1/orange1992/proxy/socks"
	_ "github.com/cherrrry1/orange1992/proxy/trojan"
	_ "github.com/cherrrry1/orange1992/proxy/vless/inbound"
	_ "github.com/cherrrry1/orange1992/proxy/vless/outbound"
	_ "github.com/cherrrry1/orange1992/proxy/vmess/inbound"
	_ "github.com/cherrrry1/orange1992/proxy/vmess/outbound"
	_ "github.com/cherrrry1/orange1992/proxy/wireguard"

	// Transports
	_ "github.com/cherrrry1/orange1992/transport/internet/domainsocket"
	_ "github.com/cherrrry1/orange1992/transport/internet/grpc"
	_ "github.com/cherrrry1/orange1992/transport/internet/http"
	_ "github.com/cherrrry1/orange1992/transport/internet/httpupgrade"
	_ "github.com/cherrrry1/orange1992/transport/internet/kcp"
	_ "github.com/cherrrry1/orange1992/transport/internet/quic"
	_ "github.com/cherrrry1/orange1992/transport/internet/reality"
	_ "github.com/cherrrry1/orange1992/transport/internet/tcp"
	_ "github.com/cherrrry1/orange1992/transport/internet/tls"
	_ "github.com/cherrrry1/orange1992/transport/internet/udp"
	_ "github.com/cherrrry1/orange1992/transport/internet/websocket"

	// Transport headers
	_ "github.com/cherrrry1/orange1992/transport/internet/headers/http"
	_ "github.com/cherrrry1/orange1992/transport/internet/headers/noop"
	_ "github.com/cherrrry1/orange1992/transport/internet/headers/srtp"
	_ "github.com/cherrrry1/orange1992/transport/internet/headers/tls"
	_ "github.com/cherrrry1/orange1992/transport/internet/headers/utp"
	_ "github.com/cherrrry1/orange1992/transport/internet/headers/wechat"
	_ "github.com/cherrrry1/orange1992/transport/internet/headers/wireguard"

	// JSON & TOML & YAML
	_ "github.com/cherrrry1/orange1992/main/json"
	_ "github.com/cherrrry1/orange1992/main/toml"
	_ "github.com/cherrrry1/orange1992/main/yaml"

	// Load config from file or http(s)
	_ "github.com/cherrrry1/orange1992/main/confloader/external"

	// Commands
	_ "github.com/cherrrry1/orange1992/main/commands/all"
)
