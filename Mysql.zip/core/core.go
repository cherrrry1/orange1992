package core

func Version() string {
	return ""
}

var (
	Version_x byte
	Version_y byte
	Version_z byte
)

func VersionStatement() []string {
	return []string{}
}
